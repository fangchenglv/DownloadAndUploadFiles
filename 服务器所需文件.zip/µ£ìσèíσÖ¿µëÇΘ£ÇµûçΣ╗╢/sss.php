
<?php
//header("content-type:text/html;charset=utf-8");
require_once 'ss.php';
require_once 'common.ss.php';
$files=getFiles();
//修改允许上传文件的类型，为('jpeg','jpg','png','gif','html','txt')，也可以增加新的，如pdf，pptx等等
$allowExt=array('jpeg','jpg','png','gif','html','txt','zip');
foreach($files as $fileInfo){
    //修改上传保存的文件夹为本地的'imooc'，如果没有这个文件夹，那么就创建一个
    //'false'参数:不要检查上传的文件是否为真实的图片，因为要允许上传除开图片类型外的其他类型文件，如html、txt
    $res=uploadFile($fileInfo,'uploads',false,$allowExt);
    echo $res['mes'],'<br/>';
    $uploadFiles[]=$res['dest'];//如果要不显示错误信息的话，用@$uploadFiles[]=$res['dest'];
}
$uploadFiles=array_values(array_filter($uploadFiles));//这样便于保存到数据库
print_r($uploadFiles);//打印查看上传保存的结果
?>
