<html>
<head>
<title>测试</title>
</head>
<body>
<h1>Hello World!</h1>
<?php phpinfo(); ?>
</body>
</html>
